

#$Checkへセキュアチャネル状況結果を代入(ture、false)
$check = Test-ComputerSecureChannel

#$Checkの結果出力
write-output $check

pause

#$Checkの結果で条件分岐
if("True" -eq $check){

#Ture処理
echo Domain-OK
pause
exit

}Else{

#False処理
#「domainname\username」は利用している「ドメイン名\監視者アカウント名」に変更すること。
echo Domain-NG
Test-ComputerSecureChannel -Repair -Credential domainname\username

pause

#1分後に再起動
shutdown /r /t 60

}


exit


#$Checkへセキュアチャネル状況結果を代入
#出力結果を目視確認後、ture or falseで処理変更
#tureの場合：Domain-OKを返して終了
#Falseの場合：ドメイン名\監視者アカウント名でログインスクリプト起勁
#　　　　　　 パスワードを入力後、Enterで60秒後に再起動